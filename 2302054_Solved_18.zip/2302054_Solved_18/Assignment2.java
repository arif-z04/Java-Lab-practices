public class Assignment2 {
    public static void main(String[] args) {
        int age = 20;
        float height = 5.8f;
        double gpa = 3.75;
        char grade = 'A';
        String name = "Arif";
        boolean isStudent = true;

        System.out.println(age);
        System.out.println(height);
        System.out.println(gpa);
        System.out.println(grade);
        System.out.println(name);
        System.out.println(isStudent);
    }
}
