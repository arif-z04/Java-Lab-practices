public class Assignment1 {
    public static void main(String[] args){
        System.out.println("Name: Arif Uzzaman.");
        System.out.println("Age: 20");
        System.out.println("Address: Patuakhali, Barisal");
        System.out.println("University: PSTU");
    }
}
